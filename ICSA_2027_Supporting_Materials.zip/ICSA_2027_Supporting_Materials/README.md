# SignalMap: ICSA 2027 SAiP Supporting Materials

Project repository: https://github.com/binthon/ICSA_2027

This archive contains reduced experimental data, reproducible numerical results,
and sanitized reference test scripts. The article and engineering thesis are
distributed separately.

## Reproduce the results

Extract the archive, open its root directory, and run:

    python -I artifact/analyze.py

Python 3.10+ with its standard library is sufficient. No installation, credentials,
Azure account, database connection, or cloud test is needed. The command prints
JSON; compare it with results/analysis.json and results/summary.md.

## Contents

- artifact/: seven data/metadata CSV files, the analyzer, source provenance,
  workload/configuration documentation, an English project-context summary, and
  an extracted arrival-schedule module.
- tests/: sanitized campaign scripts and separately identified current reference
  snapshots. See tests/README.md for their scope and dependencies.
- results/: complete analysis.json and readable summary.md.
- SOURCES.json: source paths, hashes, and packaging modifications.
- SHA256SUMS.txt: SHA-256 hashes of every other packaged file.
- PRIVACY_CHANGES.md: sanitization and English-edition changes.

## Evidence scope

E2 represents 82 exports and 445,427 rows. Aggregation uses 78 qualified runs
and 426,274 rows. Four incomplete exports remain available but are excluded.
E3 contains all 28 rounds and 84,016 events. Runs are the replication units.
Configurations and campaign series remain separate; the nominal 60-run plan is
not represented as a completed balanced matrix.

These materials reproduce numerical summaries, not the complete historical Azure
deployment or original random request sequence. Counts and queue draining do not
replace SQL reconciliation. Pod-name observations do not establish Ready
replica-minutes or monetary cost. The data establish neither a universal scaler
ranking nor PostgreSQL's maximum capacity.

## English edition and verification

Code comments and the Python module docstring were removed. Shell interpreter
directives were retained. User-facing script messages were translated into
English; test parameters, measurement CSVs, and numerical results were preserved.
Historical source paths and technical identifiers remain verbatim for provenance.
The before-GP reference runner was renamed run_e3_before_gp.sh.

The Polish README, future-experiment plan, and unrelated backup/data-deletion
helpers were omitted. The obsolete E3 sweep runner (B2s, five fixed pods)
was also omitted because it does not implement the fixed-N queue-drain experiment
reported in the paper. These omissions remove no experimental data.
Historical and current scripts remain distinct. They retain sanitized environment
placeholders and are not a complete, directly runnable cloud deployment.

During packaging, the analyzer was run from the extracted archive, its entire
JSON output was compared with the archived result, and all file checksums were
verified. Python/JavaScript/shell syntax was checked without executing cloud
scripts. No experiment, deployment, database query, or clock change was run.

Canonical numerical-result SHA-256:
da2fe15afaa4ed05fdb17751fb4fe7a7ebe7024c8b2dac432f50eef97de0482e
