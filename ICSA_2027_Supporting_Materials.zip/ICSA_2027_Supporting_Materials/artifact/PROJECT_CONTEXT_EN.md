# SignalMap project context — English summary

This is a short paraphrase of the author-supplied Polish engineering thesis, prepared to make the manuscript's project context inspectable. It is not an independent audit or a claim about the present availability of the Azure deployment.

Source: Franciszek Mazoń, Jakub Medyński, and Klaudiusz Zdrojewski, *Design and Deployment of an Application for Collecting and Visualizing Network Data in a Kubernetes Cluster on Microsoft Azure [English translation of the Polish thesis title]*, Poznan University of Technology, 2026. The manuscript cites this source as `signalmapThesis2026`.

## Context and documented choices

SignalMap combines Android collection of radio measurements and coordinates, an Azure admission and queueing pipeline, PostgreSQL/PostGIS persistence, and a Python/Flask backend with a React/deck.gl map. The thesis documents a student engineering project rather than an industrial customer deployment with a measured commercial SLA.

Section 3.3.1 explains Azure for Students access, Azure DevOps integration and reduced administration as selection factors. A managed AKS control plane limits self-managed infrastructure work. Service Bus was selected for delivery and lock control rather than Storage Queues; operating Kafka was considered excessive complexity for the anticipated scale. PostgreSQL supports the relational model and PostGIS functionality, and was familiar to the team. These statements document project rationale, not comparative provider or broker benchmarks.

## Evidence of implementation

Sections 4.6–4.9 and 5.6 document deployment automation and running components, functional/API testing, field measurement routes and map presentation. These establish that the project includes implemented application functionality. They do not establish the size of a user population or long-term operational reliability.

Section 4.9.1, printed pages 92–93, describes duplicate-elimination test TC-12. The same measurement was sent twice with the same `idempotencyKey`. Both requests received HTTP 202 and the SQL query showed one persisted record (Figures 4.18–4.19). This is the expected result for that duplicate-submission test, not evidence that one of two distinct measurements was lost and not a general exactly-once guarantee.

## Relation to the ICSA experiments

The thesis uses an Azure Functions queue consumer with multi-message processing. The ICSA fixed-N and autoscaling experiments use Kubernetes consumers so that instance count and scaling signal can be controlled explicitly. This experimental substitution is not a demonstrated performance advantage over the Function worker. Azure Function `fa-worker` remains the baseline for any later implementation comparison; a complete Function-versus-pod comparison is not claimed in the current results.

The paper's fixed `batch=1` defines the studied pod variant. Connection reuse, larger batches and the proposed concurrency caps require their own evaluations. Mobile sampling hysteresis and battery results belong to the separate IBIMA topic.

The full thesis, deployment history and final artifact release remain subject to the authors' decisions. This summary supplies context and source locations; the accompanying reduced data reproduce numerical summaries rather than the original cloud environment.
