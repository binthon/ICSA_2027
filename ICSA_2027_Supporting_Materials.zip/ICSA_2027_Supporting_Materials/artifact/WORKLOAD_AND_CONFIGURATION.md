# Workload and configuration reference

This document separates the settings reported by the paper from the materials
needed to rerun a cloud experiment. Numerical summaries are reproducible from
the packaged CSV files. Reprovisioning Azure and regenerating the original
request sequence are outside this package's scope.

## Arrival profiles

`workload_profiles_reference.mjs` extracts the `buildScenario` switch from
`archiwum_E2_20261004_2146/skrypty/load_profiles.js`. The switch body is retained;
its outer rate and duration variables become function parameters. The default
rate is 2 requests/s, matching the reported E2 campaign. The archived wrapper's
default was 5; a wrapper default is not evidence of the rate used in a run.
Source, extracted-function and packaged-module SHA-256 hashes are recorded in
`provenance.json`.

| Profile | Schedule with rate = 2 requests/s | Duration / executor |
|---|---|---|
| constant | 2 requests/s | 15 min; constant-arrival-rate |
| daily | Starts at 0; targets 0 for 5 min, then 6 over 10 min, 1 over 10 min, 10 over 10 min, 0 over 5 min | 40 min; ramping-arrival-rate |
| spike | Starts at 2; holds 2 for 5 min, ramps to 20 over 30 s, holds 20 for 5 min, returns to 2 over 2 min | 12.5 min; ramping-arrival-rate |
| spatial | 2 requests/s, with concentrated payload selection in the original wrapper | 15 min; constant-arrival-rate |

Targets in a ramping scenario describe rates at stage boundaries. They are not
independent constant-rate segments. `Math.round(2 * 0.2)` creates the initial
zero-rate daily segment. The `duration` argument affects constant and spatial;
daily and spike use their fixed stage durations. The original scenarios allocate
200 VUs, with a maximum of 500 except spike (800). The archived wrapper checks
HTTP failure rate below 0.03, check success above 0.97, and no dropped iterations.
Those generator thresholds do not establish SQL persistence or a latency SLA.

The original payload builder draws from a 5,000-record pool, adds a fresh
`event_id` and send timestamps, and uses one cell for spatial concentration.
Payload records, device registration and authentication are not included here.
The reduced event CSVs do not retain payload selection order or original IDs.
Consequently this reference reconstructs the arrival schedule, not an exact
replay of the historical requests. Observed HTTP counts remain in
`policy_runs.csv`; they must not be replaced by a nominal profile integral.

The extracted module has no imports and performs no HTTP, shell, or cloud
operations. Existing Node.js can import `buildScenario(profile, rate, duration)`
to inspect the resulting scenario object. It is not a standalone k6 load test.
The archived `skrypty` snapshot does not contain its imported `lib` directory;
the current project's library must not be presented as a verified historical
snapshot.

## Configuration scope

| Component | Settings reported for the four-replica policy series |
|---|---|
| Pod worker | batch = 1; prefetch = 10; maximum receive wait = 5 s |
| Pod resources | current manifests: CPU request 250m, limit 1 core, memory 512 MiB |
| HPA | CPU target 3% of request, equivalent to 7.5m at request 250m |
| KEDA | Service Bus message-count target 3 |
| Feedback | client-to-commit histogram p95 target 1.44 s; distinct from the outcome metric |
| Four-replica series bounds | minimum 1, maximum 4 |
| Database configurations | Burstable B1ms and General Purpose D2s_v3 |

The current resource manifests are reference material, not proof of historical
cluster state. Earlier E2 cohorts have different constraints, including a KEDA
maximum of 30. Do not use the four-replica table as a common snapshot for all 82
exports. E3 used fixed consumer counts rather than an active scaling policy.

Historical Terraform state, exact image digests, complete configuration
snapshots and a ready-to-run authenticated cloud environment are not supplied.
Do not infer those settings from missing files or silently replace them with
current deployments. A new campaign needs recorded versions, a separate pilot, frozen qualification rules, and complete outcome collection.


## Additional experimental context

Both manuscript versions include RQ1-RQ3, three related-work themes, a database
configuration table, and nominal workload schedules. Spatial uses the constant
arrival schedule with a different payload distribution. These schedules are not
measured application throughput.

Author-supplied Azure Portal screenshots show B1ms with 1 vCore and 2 GiB RAM,
and D2s_v3 with 2 vCores and 8 GiB RAM. Compute-size IOPS limits are 640 and 3200;
both disks are Premium SSD, 32 GiB, P4, 120 IOPS, with autogrow and HA disabled.
The screenshots are undated and do not independently establish each historical
round's configuration. No unspecified parameters were inferred.
