export function buildScenario(profile, rate = 2, duration = '15m') {
  const RATE = Number(rate);
  const SHORT_PROFILE_DURATION = duration || '15m';
  if (!Number.isFinite(RATE) || RATE <= 0) throw new RangeError('rate must be positive');
  switch (profile) {
    case 'constant':
      return {
        executor: 'constant-arrival-rate',
        rate: RATE, timeUnit: '1s', duration: SHORT_PROFILE_DURATION,
        preAllocatedVUs: 200, maxVUs: 500,
      };

    case 'daily':
      return {
        executor: 'ramping-arrival-rate',
        startRate: Math.round(RATE * 0.2), timeUnit: '1s',
        preAllocatedVUs: 200, maxVUs: 500,
        stages: [
          { target: Math.round(RATE * 0.2), duration: '5m' },
          { target: Math.round(RATE * 3), duration: '10m' },
          { target: Math.round(RATE * 0.5), duration: '10m' },
          { target: Math.round(RATE * 5), duration: '10m' },
          { target: Math.round(RATE * 0.2), duration: '5m' },
        ],
      };

    case 'spike':
      return {
        executor: 'ramping-arrival-rate',
        startRate: RATE, timeUnit: '1s',
        preAllocatedVUs: 200, maxVUs: 800,
        stages: [
          { target: RATE, duration: '5m' },
          { target: RATE * 10, duration: '30s' },
          { target: RATE * 10, duration: '5m' },
          { target: RATE, duration: '2m' },
        ],
      };

    case 'spatial':
      return {
        executor: 'constant-arrival-rate',
        rate: RATE, timeUnit: '1s', duration: SHORT_PROFILE_DURATION,
        preAllocatedVUs: 200, maxVUs: 500,
      };

    default:
      throw new Error(`Unknown PROFILE: "${profile}". Use: constant | daily | spike | spatial`);
  }
}
