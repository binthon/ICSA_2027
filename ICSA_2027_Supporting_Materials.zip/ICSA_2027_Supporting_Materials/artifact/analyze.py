from pathlib import Path
from collections import defaultdict, Counter
import csv
import json
import statistics as st
import datetime as dt

HERE = Path(__file__).resolve().parent

def read(name):
    with (HERE / name).open(encoding='utf-8', newline='') as stream:
        return list(csv.DictReader(stream))

def quantile(values, q):
    values = sorted(values)
    position = (len(values)-1)*q
    lower = int(position)
    upper = min(lower+1, len(values)-1)
    return values[lower]+(values[upper]-values[lower])*(position-lower)

def capacity_validation(capacity_runs):
    metadata = {row['run']: row for row in read('capacity_runs.csv')}
    assert len(metadata) == 28 and metadata.keys() == capacity_runs.keys()
    samples = defaultdict(lambda: defaultdict(list))
    for row in read('capacity_metrics.csv'):
        run = row['run']
        start = dt.datetime.fromisoformat(metadata[run]['start_utc'].replace('Z', '+00:00'))
        end = dt.datetime.fromisoformat(metadata[run]['end_utc'].replace('Z', '+00:00'))
        elapsed, interval = float(row['elapsed_s']), float(row['interval_s'])

        if 0 <= elapsed and elapsed+interval <= (end-start).total_seconds():
            samples[run][row['metric']].append(float(row['value']))
    groups, rounds = defaultdict(list), []
    for run, rows in capacity_runs.items():
        meta, values = metadata[run], samples[run]
        assert int(meta['backlog']) == len(rows)
        assert values['cpu_percent'] and values['active_connections'] and values['ready_replicas']
        times = [float(row['elapsed_s']) for row in rows]
        log_rate = len(rows)/(max(times)-min(times))
        replicas = int(meta['replicas'])
        row = dict(run=run, tier=meta['tier'], profile=meta['profile'], replicas=replicas,
            campaign_order=int(meta['campaign_order']), start_utc=meta['start_utc'], end_utc=meta['end_utc'],
            log_rate=log_rate, drain_rate=int(meta['backlog'])/float(meta['drain_s']),
            busy_fraction=log_rate*st.mean(float(r['worker_ms']) for r in rows)/1000/replicas,
            cpu_mean_percent=st.mean(values['cpu_percent']),
            cpu_p95_minute_mean_percent=quantile(values['cpu_percent'], .95),
            cpu_minute_samples=len(values['cpu_percent']),
            active_connections_mean=st.mean(values['active_connections']),
            credits_min=min(values['cpu_credits_remaining']) if values['cpu_credits_remaining'] else None,
            ready_replicas_max=max(values['ready_replicas']))
        assert row['ready_replicas_max'] == replicas
        rounds.append(row)
        groups[meta['tier'], meta['profile'], replicas].append(row)
    summary = []
    for (tier, profile, replicas), values in sorted(groups.items()):
        rates = [r['drain_rate'] for r in values]
        credits = [r['credits_min'] for r in values if r['credits_min'] is not None]
        summary.append(dict(tier=tier, profile=profile, replicas=replicas, rounds=len(values),
            mean_drain_rate=st.mean(rates), min_drain_rate=min(rates), max_drain_rate=max(rates),
            mean_round_cpu_percent=st.mean(r['cpu_mean_percent'] for r in values),
            mean_round_p95_cpu_minute_percent=st.mean(r['cpu_p95_minute_mean_percent'] for r in values),
            mean_round_active_connections=st.mean(r['active_connections_mean'] for r in values),
            min_observed_credits=min(credits) if credits else None,
            min_cpu_samples=min(r['cpu_minute_samples'] for r in values),
            max_cpu_samples=max(r['cpu_minute_samples'] for r in values)))
    busy = [r['busy_fraction'] for r in rounds]
    return dict(summary=summary, rounds=sorted(rounds, key=lambda row: (row['tier'], row['campaign_order'])),
                busy_fraction_min=min(busy), busy_fraction_max=max(busy),
                burstable_credit_min=min(r['credits_min'] for r in rounds if r['credits_min'] is not None))

def analyze():
    capacity_runs = defaultdict(list)
    capacity_rows = read('capacity_events.csv')
    assert len(capacity_rows) == 84016
    for row in capacity_rows:
        capacity_runs[row['run']].append(row)
    assert len(capacity_runs) == 28
    capacity_groups = defaultdict(list)
    for run, rows in capacity_runs.items():
        first = rows[0]
        times = [float(row['elapsed_s']) for row in rows]
        span = max(times)-min(times)
        assert span > 0
        key = (first['tier'], first['profile'], int(first['replicas']))
        capacity_groups[key].append(dict(rate=len(rows)/span,
                                         worker=st.median(float(row['worker_ms']) for row in rows)))
    capacity = []
    for (tier, profile, replicas), runs in sorted(capacity_groups.items()):
        rates = [run['rate'] for run in runs]
        capacity.append(dict(tier=tier, profile=profile, replicas=replicas, rounds=len(runs),
                             mean_rate=st.mean(rates), min_rate=min(rates), max_rate=max(rates),
                             sample_sd_rate=st.stdev(rates),
                             cv_rate_percent=100*st.stdev(rates)/st.mean(rates),
                             mean_round_median_worker_ms=st.mean(run['worker'] for run in runs)))

    policy_runs, pod_runs = defaultdict(list), defaultdict(list)
    for row in read('policy_events.csv'):
        policy_runs[row['run']].append(row)
    for row in read('policy_pods.csv'):
        pod_runs[row['run']].append(float(row['observed_pods']))
    qualifications = {row['run']: row for row in read('policy_runs.csv')}
    assert len(policy_runs) == len(qualifications) == 82
    role_counts = Counter(row['role'] for row in qualifications.values())
    assert role_counts == {'principal': 17, 'supplementary': 61, 'excluded': 4}
    policy_groups, supplementary_groups, archive_groups = defaultdict(list), defaultdict(list), defaultdict(list)
    completeness = Counter()
    selection = defaultdict(Counter)
    run_statistics = {}
    for run, rows in policy_runs.items():
        metadata = qualifications[run]
        unique = len({row['event_index'] for row in rows})
        accepted = int(metadata['accepted_202'])
        assert len(rows) == int(metadata['raw_rows']) and unique == int(metadata['unique_events'])
        assert all(row['series'] == metadata['series'] and row['policy'] == metadata['policy'] for row in rows)
        cohort = ('earlier_series' if metadata['series'].endswith('_earlier') else
                  'daily_controls' if metadata['series'] == 'daily_control' else
                  'corrective_spike' if metadata['series'] == 'spike_observational' else 'corrective_spatial')
        selection[cohort]['archived'] += 1
        selection[cohort][metadata['role']] += 1
        completeness[metadata['quality']] += 1
        if metadata['role'] == 'excluded':
            assert unique < accepted and metadata['quality'] == 'incomplete'
            continue
        assert unique == len(rows) and unique >= accepted
        assert (metadata['quality'] == 'count_agreement') == (unique == accepted)
        key = rows[0]['series'], rows[0]['policy']
        p95 = quantile([float(row['sb_to_worker_ms'])+float(row['worker_total_ms']) for row in rows],.95)/1000
        assert pod_runs[run]
        values = p95, st.mean(pod_runs[run])
        archive_groups[key].append(values)
        (policy_groups if metadata['role'] == 'principal' else supplementary_groups)[key].append(values)
        run_statistics[run] = values
    assert completeness == {'count_agreement': 77, 'acknowledgment_mismatch': 1, 'incomplete': 4}
    assert sum(len(rows) for rows in policy_runs.values()) == 445427
    assert sum(len(policy_runs[run]) for run, row in qualifications.items() if row['role'] != 'excluded') == 426274

    def summaries(groups):
        result = []
        for (series, control), runs in sorted(groups.items()):
            p95s = [run[0] for run in runs]
            result.append(dict(series=series, policy=control, runs=len(runs),
                               median_p95_s=st.median(p95s), min_p95_s=min(p95s), max_p95_s=max(p95s),
                               median_mean_observed_pods=st.median(run[1] for run in runs)))
        return result

    feedback_constant = [run for run, row in qualifications.items()
                         if row['series'] == 'constant_earlier' and row['policy'] == 'feedback']
    exact = [run for run in feedback_constant if qualifications[run]['quality'] == 'count_agreement']
    sensitivity = dict(series='constant_earlier', policy='feedback',
                       retained_runs=len(feedback_constant), count_agreement_runs=len(exact),
                       all_median_p95_s=st.median(run_statistics[run][0] for run in feedback_constant),
                       count_agreement_median_p95_s=st.median(run_statistics[run][0] for run in exact))
    return {'capacity': capacity, 'capacity_validation': capacity_validation(capacity_runs),
            'policy': summaries(policy_groups),
            'policy_supplementary': summaries(supplementary_groups),
            'policy_archive': summaries(archive_groups),
            'selection': {group: dict(counts) for group, counts in sorted(selection.items())},
            'completeness': dict(completeness), 'acknowledgment_sensitivity': sensitivity}

if __name__ == '__main__':
    print(json.dumps(analyze(),indent=2))
