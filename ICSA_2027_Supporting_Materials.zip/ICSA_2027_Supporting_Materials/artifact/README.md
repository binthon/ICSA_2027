# Numerical reproduction package for ICSA SAiP

Run `python analyze.py` from any directory, or `python -I analyze.py` to isolate the run from user-installed Python packages. Only the Python standard library is required. The JSON written to stdout reproduces the capacity, selection, and expanded policy tables in both PL and EN manuscripts, including between-round sample standard deviation and coefficient of variation, plus the acknowledgment-mismatch sensitivity analysis.

This package accompanies the SignalMap study. Repository location and release management are described in the root README.

## Data and transformations

- `capacity_events.csv`: all 84,016 exported events from 28 original capacity runs; generated run codes replace original names. Log timestamps become seconds relative to the first event in that run. Database connection, INSERT and total worker durations retain their exported millisecond values.
- `capacity_summary.csv`: all 12 capacity groups, with round count, mean throughput, sample standard deviation (denominator n-1), coefficient of variation in percent, observed minimum/maximum and mean per-round median worker time. Rates/SD use messages/s; worker time uses milliseconds. The constant-group CV range is 0.08–5.02%. With 2–3 rounds these describe observed dispersion, not statistical significance or independent-event replication. The main capacity table shows mean ± sample SD and n; the figure retains all round points and min/max ranges.
- `capacity_runs.csv`: all 28 runner windows with UTC start/end, chronological order within each database campaign, backlog, recorded drain duration and available before/after credits. These UTC windows are intentionally included to document chronology; event identifiers and resource addresses remain omitted.
- `capacity_metrics.csv`: original minute-average database CPU, active connections and available credits, plus point samples of the fixed deployment's Ready replicas. Times are seconds relative to runner start. Boundary and padded samples are retained in this CSV; the analysis selects only complete 60-second Azure buckets inside the runner window. Ready point samples use interval zero and the closed runner window. General Purpose credit samples are absent, not zero-filled.
- `policy_events.csv`: all 445,427 exported rows from the 82 policy runs, including the four incomplete exports. Original measurement identifiers are replaced by an integer `event_index` scoped to each generated run code. Repeated identifiers retain the same index within a run, allowing unique-event counts to be reproduced without disclosing original identifiers. Latency components remain in milliseconds; coordinates, pod names and client timestamps are omitted.
- `policy_pods.csv`: 1,652 original minute inventory samples within each run's k6 window, start inclusive and end exclusive. The observation time is relative to run start. Counts originate from `dcount(Name)` in `KubePodInventory`, without Ready filtering; they are not resource-consumption measurements.
- `policy_runs.csv`: qualification of every one of the 82 exports. It records cohort, profile, policy, role (`principal`, `supplementary`, or `excluded`), quality flag, inclusion/exclusion reason, raw and unique-event counts, accepted-202 count, observed initial inventory count, first-minute emitting-pod count, database-credit minimum from the audit, and window duration. Neither initial inventory count nor first-minute emitters establish Ready state. Daily's initial idle segment can produce zero first-minute emitters.
- `WORKLOAD_AND_CONFIGURATION.md` and `workload_profiles_reference.mjs`: settings and extracted arrival-scenario logic. The module performs no load generation and omits HTTP/authentication/payload handling. The archive lacks the imported historical lib directory, so these files do not claim a complete historical load runner.
- `provenance.json`: run-level source hashes, row counts and classifications, plus hashes of the prior completion audit, k6 audit and daily reset proof used by the preparation script. A separate workload-reference record contains the archived generator hash, extracted-function hash, packaged-module hash and historical-library availability flag. It contains no original message IDs, coordinates, original run names, resource addresses, or access credentials.

Capacity rate is event count divided by the span of relative log-emission timestamps, not full deployment-to-drain time. Group statistics use runs as the replication unit; the worker-time series is the mean of within-run medians. Policy latency uses `sb_to_worker_ms + worker_total_ms`, linear-interpolation p95 per run and then the median between runs. Pod counts use the mean within each k6 window and then the median between runs.

## E3 timing and monitoring cross-checks

The additional `capacity_validation` output reports per-round values and grouped summaries. `drain_rate` is backlog divided by `drain_s`, recorded from immediately before `kubectl scale` until the runner first sees a zero `countDetails.activeMessageCount` from `az servicebus queue show`. The numerator is the same counter after prefilling and before scaling. The runner sleeps 5 seconds between nonzero observations, so CLI duration also contributes to the interval. It includes startup and queue polling. No separate client-cache/in-flight or SQL reconciliation is performed by that stopping rule, so zero is not independent confirmation of the last SQL commit. Both rate estimators concern the same rounds and test timing-boundary sensitivity; they are not independent experimental replications. For example, group means are 9.436499 messages/s at Burstable N=2 and 18.243330 at General Purpose N=3, compared with log-span means of 9.712925 and 18.839820.

Database CPU/connection statistics use only fully contained minute buckets. The main diagnostic table averages per-round mean CPU and per-round mean connection counts and gives the number of CPU buckets per round. The Azure metric `active_connections` counts connections in all states, including idle, despite its name. The JSON additionally preserves per-round p95 of minute-average CPU as an ancillary statistic; this p95 is omitted from the main table. There are only 1–7 complete CPU buckets per round; these values are descriptive and do not estimate the distribution of instantaneous CPU use. Samples cover all 28 rounds for CPU/connections and all 16 Burstable rounds for credits. The minimum retained minute-average `cpu_credits_remaining` is 100 credits (Azure unit Count, not percent or a claim that the balance equals its maximum). Coarse observations do not establish identical initial conditions or exclude all forms of throttling.

The busy-time check is log-span rate multiplied by the arithmetic mean worker duration in seconds, divided by N. Across all rounds it ranges from 0.941808 to 0.983020. It is a consistency check for consumer activity, not independent identification of contention or database saturation. The plotted worker-duration series still uses within-run medians and must not be substituted into Little's average relationship.

Burstable windows fall on 5 October 2026 and General Purpose on 5–6 October. Campaign order is recorded rather than assumed randomized. `provenance.json` records the runner-file hash and CPU/connection/credit/Ready-source hashes for every E3 round. The numerator is still exported events, not independently reconciled SQL rows.

`PROJECT_CONTEXT_EN.md` provides an English paraphrase of the thesis context with source sections. Proposed replica limits and connection reuse remain unvalidated interventions; this archive contains no new cloud measurements.

## Qualification and cohort separation

All 82 exports are retained in the package; 78 runs / 426,274 event rows enter policy aggregation. The manuscript reports all 78 together, separated by campaign stage, profile and configuration. Legacy principal/supplementary roles remain in the CSV for traceability rather than defining separate evidence classes in the article. The nominal plan was 60 runs (3 policies × 4 profiles × 5 repetitions); this does not establish a completed 60-run baseline plus 22 reruns. Four spike exports with fewer unique completions than accepted-202 responses are excluded from percentile aggregation. This does not identify whether missing coverage originates in export or processing.

| Campaign stage | Archived | Included | Incomplete |
|---|---:|---:|---:|
| Earlier series | 53 | 51 | 2 |
| Later spatial | 10 | 10 | 0 |
| Later spike | 15 | 13 | 2 |
| Daily start controls | 4 | 4 | 0 |
| Total | 82 | 78 | 4 |

The excluded earlier spikes have 3,504 and 3,374 unique completions (3,623 and 3,515 raw rows, including repeated IDs); the excluded corrective spikes have 5,992 and 6,023 unique completions. Each has 8,249 accepted-202 responses. The package preserves the duplicate indexes in the earlier incomplete exports.

Among included runs, 77 have numerical agreement of unique completions and accepted-202 counts. One earlier constant-feedback run has 1,800 unique completions and 1,799 responses with 202. It is retained with an `acknowledgment_mismatch` flag: absence of an observed 202 is not proof of failed persistence. Excluding this run changes the cohort's median per-run p95 from 0.197205 to 0.198350 seconds. The output reports both values.

Legacy series labels retained for mapping earlier manuscript versions: A = `daily_control`; B = `spike_observational`; C = `constant_earlier`; D = `daily_earlier`; E = `spatial_earlier`; F = `spike_earlier`; G = `spatial_corrective`. C--F retain their historical configuration and start-state limitations; G has KEDA/feedback but no matching HPA cohort. Only A has the cited daily replica-reset proof. Cohorts are not pooled across profiles or campaign stages. The earlier and control daily cohorts reverse HPA--feedback latency ordering, so the expanded results do not establish a universal controller ranking.

The JSON keys `policy` (17 legacy principal runs) and `policy_supplementary` (61 legacy supplementary runs) remain for compatibility; the manuscript uses `policy_archive` (all 78 qualified runs). Its table groups by profile and policy, placing earlier and later series in separate column groups and preserving n, median p95, p95 range and median mean observed pods. This layout implies no controlled before/after intervention. `selection` and `completeness` provide the accounting; `acknowledgment_sensitivity` reports the sensitivity check.

For maintainers, preparation from the original workspace exports is implemented in `.codex-analysis-tools/prepare_icsa_reproduction.py` at project root. It cross-checks raw row and unique-event counts against `results/audyt_E2_szczegolowy_20261008.json`, accepted-202 counts against `results/audyt_k6_pelny_20261008.json`, and principal daily classifications against `reset_proof_daily.txt`. These archived audits summarize the original client traces; the reduced package does not independently reconstruct HTTP responses. The packaged `analyze.py` uses only the reduced CSV files. Original cloud setup, API behavior, clock accuracy, source-export completeness, and Ready-state proof cannot be reconstructed from this dataset alone. The package reproduces numerical summaries, not the entire cloud experiment.

## Local review archive

The supporting ZIP contains reduced E2/E3 data, the analysis script, results and sanitized test-script snapshots. The article and its LaTeX sources are provided separately. `SHA256SUMS.txt` at the archive root covers all other packaged files; `SOURCES.json` records the provenance of source-derived files. The archive is not a complete cloud deployment. Distribution is not implied by packaging; the article availability statement must be updated only after actual reviewer access or public access is arranged.

Metric definitions were checked against [Service Bus counters](https://learn.microsoft.com/en-us/azure/service-bus-messaging/message-counters) and [PostgreSQL monitoring](https://learn.microsoft.com/en-us/azure/postgresql/monitor/concepts-monitoring) on 21 October 2026.

## Scaling-target provenance

The documented four-replica configuration uses CPU utilization 3% relative to a 250m pod request (7.5m CPU), KEDA messageCount 3 as an active-message target per replica, and client-to-commit p95 target 1.44 s for feedback. Values are present in the campaign switching script and feedback manifests. The campaign README does not establish pilot calibration of HPA/feedback targets against a common quality objective; the article does not invent one. Earlier spike KEDA's limit of 30 is retained as a distinct configuration from later spike capped at 4. The table's earlier/later grouping does not establish an intervention effect or general controller ranking.

## English edition

Code comments and documentation strings were removed, and script messages were translated. The numerical analysis logic and measurement CSVs are unchanged. Historical source hashes describe the original inputs; current packaged-file hashes are in SOURCES.json and SHA256SUMS.txt. Future-experiment plans and backup/data-deletion helpers are not included.
