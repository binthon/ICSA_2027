# Changes applied to the reviewer ZIP

1. Removed a real Azure API Management hostname from archived command examples and a k6 configuration module. The k6 module now **requires** `APIM_URL` instead of silently using a historical deployment address.
2. Replaced actual Azure subscription/identity UUIDs, resource group, PostgreSQL server, Service Bus namespace, Log Analytics workspace, Kubernetes context and one local computer user path with descriptive `YOUR_*` placeholders in `tests/` scripts.
3. Removed the article sources and PDFs from the supporting ZIP; the article is handled as a separate submission.
4. Updated the metadata in `SOURCES.json`, recomputed `SHA256SUMS.txt` and verified the measurement analysis without cloud access.

Public third-party documentation URLs, standard `management.azure.com` API endpoints, `localhost`/`127.0.0.1` development URLs, and citation URLs have not been altered.

These modified scripts are **sanitized snapshots**. They no longer represent byte-for-byte original historical files, and require environment-specific configuration if someone later wants to run them. Measurement CSV data and numerical results remain byte-identical. The analyzer differs only by removal of comments and its module docstring; its Python syntax tree and computed results are unchanged.

## English packaging

Code comments were removed; interpreter directives were kept. Script messages were translated into English. The Polish README, future-experiment plan, and stand-alone backup/data-deletion helpers were omitted. The before-GP runner was renamed run_e3_before_gp.sh. Documentation, source metadata, and integrity hashes were updated. No measurement values or analysis operations were changed.

## Experiment-scope cleanup

The obsolete E3 sweep runner using B2s and five fixed pods was removed. It describes a different historical experiment from the fixed-N queue-drain rounds analyzed in the paper. The remaining test inventory and source manifest were updated. Measurement CSVs, analysis code, and numerical results were not changed.
