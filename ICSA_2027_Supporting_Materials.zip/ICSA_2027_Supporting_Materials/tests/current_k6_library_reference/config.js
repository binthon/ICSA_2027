export const BASE_URL = __ENV.APIM_URL;

export const SHORT_CODE = __ENV.SHORT_CODE;

export const SUBSCRIPTION_KEY = __ENV.SUBSCRIPTION_KEY || null;

export const TOKEN_BROKER_URL = __ENV.TOKEN_BROKER_URL || null;

export const PROFILE = __ENV.PROFILE || 'unknown';
export const CONFIG = __ENV.CONFIG || 'unknown';
export const RUN_ID = __ENV.RUN_ID || 'manual';
export const VARIANT = __ENV.VARIANT || CONFIG;

if (!BASE_URL) {
  throw new Error('APIM_URL is missing. Supply the target address using --env APIM_URL=...');
}

if (!SHORT_CODE) {
  throw new Error(
    'SHORT_CODE is missing. Run register_device.js to register the test device, ' +
    'then supply the returned shortCode using --env SHORT_CODE=...'
  );
}
