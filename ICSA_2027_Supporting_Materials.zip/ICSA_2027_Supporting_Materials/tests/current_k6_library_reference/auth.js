import http from 'k6/http';
import { BASE_URL, SHORT_CODE, SUBSCRIPTION_KEY, TOKEN_BROKER_URL } from './config.js';

let cachedToken = null;
let tokenExpEpochSec = 0;

function nowEpochSec() {
  return Math.floor(Date.now() / 1000);
}

function isTokenValid() {
  return cachedToken !== null && nowEpochSec() < tokenExpEpochSec - 30;
}

export function getToken() {
  if (isTokenValid()) {
    return cachedToken;
  }

  let url = `${BASE_URL}/submit/gettoken`;
  const headers = {};

  if (TOKEN_BROKER_URL) {
    url = TOKEN_BROKER_URL;
  } else {
    headers['X-Short-Code'] = SHORT_CODE;
    if (SUBSCRIPTION_KEY) {
      headers['Ocp-Apim-Subscription-Key'] = SUBSCRIPTION_KEY;
    }
  }

  const res = http.get(url, { headers, tags: { name: 'gettoken' } });

  if (res.status !== 200) {
    throw new Error(`gettoken failed: HTTP ${res.status} — ${res.body}`);
  }

  const body = JSON.parse(res.body);
  if (!body.access_token || !body.expires_at) {
    throw new Error(`gettoken returned an invalid payload: ${res.body}`);
  }

  cachedToken = body.access_token;
  tokenExpEpochSec = body.expires_at;
  return cachedToken;
}
