import { SharedArray } from 'k6/data';
import { SHORT_CODE } from './config.js';

const pool = new SharedArray('telemetry_pool', function () {
  
  const path = __ENV.PAYLOAD_FILE || '../data/telemetry_sample.json';
  return JSON.parse(open(path));
});

const spatialPool = new SharedArray('telemetry_spatial_pool', function () {
  const path = __ENV.SPATIAL_PAYLOAD_FILE || '../data/telemetry_spatial.json';
  try {
    return JSON.parse(open(path));
  } catch (e) {
    return [];
  }
});

const spatialCellId = String(__ENV.SPATIAL_CELL_ID || '8314471');
const derivedSpatialPool = [];
for (let i = 0; i < pool.length; i += 1) {
  if (String(pool[i].cell_id) === spatialCellId) derivedSpatialPool.push(pool[i]);
}

export function newEventId() {
  
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = Math.floor(Math.random() * 16);
    const v = c === 'x' ? r : ((r & 0x3) | 0x8);
    return v.toString(16);
  });
}

export function buildTelemetryPayload(spatial = false, eventId = newEventId()) {
  const spatialSource = spatialPool.length > 0 ? spatialPool : derivedSpatialPool;
  if (spatial && spatialSource.length === 0) {
    throw new Error(
      `No data for SPATIAL_CELL_ID=${spatialCellId}. Generate data/telemetry_spatial.json.`
    );
  }

  const source = spatial ? spatialSource : pool;
  if (source.length === 0) {
    throw new Error('The telemetry pool is empty; check PAYLOAD_FILE.');
  }
  const base = source[Math.floor(Math.random() * source.length)];

  return {
    event_id: eventId,
    operator: base.operator,
    network_type: base.network_type,
    signal: base.signal,
    lat: base.lat,
    lon: base.lon,
    send_time: new Date().toISOString(),

    client_sent_at: new Date().toISOString(),

    short_code: SHORT_CODE,
    rat: base.rat,
    band: base.band,
    arfcn: base.arfcn,
    rsrp: base.rsrp,
    rsrq: base.rsrq,
    sinr: base.sinr,
    rssi: base.rssi,
    pci: base.pci,
    cell_id: base.cell_id,
    enb: base.enb,
    sector_id: base.sector_id,
    tac: base.tac,
    lac: base.lac,
  };
}
