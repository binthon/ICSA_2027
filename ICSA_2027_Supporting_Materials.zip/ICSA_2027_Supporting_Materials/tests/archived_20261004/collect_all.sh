#!/bin/bash
ROOT=${PROJECT_ROOT:?Set PROJECT_ROOT to local infrastructure root}
T=$ROOT/tests_icsa
ARCH=$T/archiwum_E2_$(date -u +%Y%m%d_%H%M)
mkdir -p "$ARCH"/{eksporty,logi,skrypty,konfig,dump_cfg,surowe_e2e,repliki_min,window,metryki}
LOG="$ARCH/manifest.log"; exec > >(tee -a "$LOG") 2>&1
cd "$T"
echo "=== START $(date -u +%FT%TZ) ==="
echo "--- Log Analytics retention (days):"
az monitor log-analytics workspace show -g YOUR_AZURE_RESOURCE_GROUP -n YOUR_LOG_ANALYTICS_WORKSPACE --query retentionInDays -o tsv | tr -d '\r'
echo "--- 1. exports and time windows"
cp -v e2e_*.csv replicas_*.csv compendium_runs_auto.csv runs_capped.json reset_proof_daily.txt "$ARCH/eksporty/" 2>&1
cp results/*_window.json "$ARCH/window/" 2>&1
echo "--- 2. logs and home-directory files"
cp -v ~/e2_*.log ~/spike_reset_lines.txt ~/feedback_metric_run1.json "$ARCH/logi/" 2>&1
echo "--- 3. scripts, generator and configurations"
cp -v scripts/*.sh run_e3.sh collect_all.sh load_profiles.js "$ARCH/skrypty/" 2>&1
cp -rv lib data "$ARCH/skrypty/" 2>&1 | tail -1
for f in $ROOT/k8s/k8s_config/fa-worker/chart/values.yaml $ROOT/k8s/k8s_config/k8s-fa-worker-keda/helmrelease.yaml $ROOT/k8s/k8s_config/k8s-fa-worker-feedback/*.yaml; do
  [ -f "$f" ] && cp -v "$f" "$ARCH/konfig/$(echo "$f" | sed 's#.*/k8s_config/##; s#/#__#g')" || echo "MISSING: $f"
done
echo "--- 4. cluster snapshots"
D="$ARCH/dump_cfg"
kubectl get hpa,scaledobject,deployment,configmap -n fa-worker -o yaml > $D/fa-worker_objects.yaml
kubectl get prometheusrule -n fa-worker -o yaml > $D/prometheusrule.yaml 2>/dev/null
helm get values fa-worker -n fa-worker > $D/helm_values.yaml
kubectl get nodes -L agentpool,node.kubernetes.io/instance-type > $D/nodes.txt
echo "--- 5. Azure metrics"
DB="/subscriptions/YOUR_AZURE_SUBSCRIPTION_ID/resourceGroups/YOUR_AZURE_RESOURCE_GROUP/providers/Microsoft.DBforPostgreSQL/flexibleServers/YOUR_POSTGRES_SERVER"
SB=$(az servicebus namespace show -g YOUR_AZURE_RESOURCE_GROUP -n YOUR_SERVICEBUS_NAMESPACE --query id -o tsv | tr -d '\r')
S=2026-09-30T00:00:00Z; E=$(date -u +%Y-%m-%dT%H:%M:%SZ)
for m in cpu_credits_remaining cpu_percent active_connections; do
  az monitor metrics list --resource "$DB" --metric $m --interval PT5M --start-time $S --end-time $E --query "value[0].timeseries[0].data[].[timeStamp,average,maximum]" -o tsv > "$ARCH/metryki/db_$m.tsv"
done
az monitor metrics list --resource "$SB" --metric ActiveMessages --interval PT1M --start-time $S --end-time $E --aggregation Maximum --query "value[0].timeseries[0].data[].[timeStamp,maximum]" -o tsv > "$ARCH/metryki/sb_ActiveMessages.tsv"
echo "--- 6. raw e2e and minute-level replicas (all runs from compendium_runs_auto.csv)"
WS=$(az monitor log-analytics workspace show -g YOUR_AZURE_RESOURCE_GROUP -n YOUR_LOG_ANALYTICS_WORKSPACE --query customerId -o tsv | tr -d '\r')
python3 - << 'PY'
import glob, json, csv, os
from datetime import datetime, timedelta
rows=[]
for p in glob.glob("results/*_window.json")+glob.glob("results_backup_*/*_window.json"):
    try: d=json.load(open(p))
    except Exception: continue
    rows.append((d["run_id"],d["variant"],d["start"],d["end"]))
rows=sorted(set(rows), key=lambda r:r[2])
with open("/tmp/runs_all.tsv","w") as f:
    for r in rows: f.write("\t".join(r)+"\n")
print(len(rows),"runs")
PY
while IFS=$'\t' read -r rid v s e; do
  [ -f "$ARCH/surowe_e2e/$rid.tsv" ] && continue
  echo ">>> $rid"
  q1="ContainerLogV2 | where TimeGenerated between (datetime($s) .. datetime($e) + 15m) | where PodName startswith \"fa-worker-$v\" and LogMessage contains \"LAT event_id\" | parse LogMessage with * \"event_id=\" eid:string \" \" * | parse LogMessage with * \"from_fs_to_sb_enqueue=\" enq:real \" \" * | parse LogMessage with * \"from_sb_to_worker=\" sbw:real \" \" * | parse LogMessage with * \"worker_total_duration=\" wtot:real \" \" * | parse LogMessage with * \"from_client_to_db_commit=\" e2e:real \" \" * | extend sent = TimeGenerated - e2e * 1ms | where sent between (datetime($s) .. datetime($e)) | project eid, TimeGenerated, PodName, enq, sbw, wtot, e2e, sent | order by sent asc"
  echo -e "table\teid\ttime_generated\tpod\tfs_to_sb_enqueue_ms\tsb_to_worker_ms\tworker_total_ms\te2e_ms\tsent" > "$ARCH/surowe_e2e/$rid.tsv"
  az monitor log-analytics query --workspace "$WS" --analytics-query "$q1" -o tsv </dev/null >> "$ARCH/surowe_e2e/$rid.tsv"
  q2="KubePodInventory | where TimeGenerated between (datetime($s) .. datetime($e) + 20m) | where Namespace == \"fa-worker\" and Name startswith \"fa-worker-$v\" | summarize pods=dcount(Name) by bin(TimeGenerated, 1m) | order by TimeGenerated asc"
  echo -e "table\tminute\tpods" > "$ARCH/repliki_min/$rid.tsv"
  az monitor log-analytics query --workspace "$WS" --analytics-query "$q2" -o tsv </dev/null >> "$ARCH/repliki_min/$rid.tsv"
  echo "    e2e: $(($(wc -l < "$ARCH/surowe_e2e/$rid.tsv")-1))  replicas(min): $(($(wc -l < "$ARCH/repliki_min/$rid.tsv")-1))"
  sleep 1
done < /tmp/runs_all.tsv
echo "--- 7. manifest and checksums"
( cd "$ARCH" && find . -type f ! -name manifest.log ! -name SHA256SUMS.txt -print0 | xargs -0 sha256sum > SHA256SUMS.txt; wc -l SHA256SUMS.txt; du -sh . )
echo "=== END $(date -u +%FT%TZ) -> $ARCH ==="
echo "Back up separately:  tar czf $T/backupy_results.tgz -C $T results results_backup_*"
