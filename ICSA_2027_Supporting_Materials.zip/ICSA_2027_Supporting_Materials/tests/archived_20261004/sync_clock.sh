#!/bin/bash

set -euo pipefail

NTP_SERVER="${NTP_SERVER:-time.windows.com}"

sync_via_https_fallback() {
    echo ">>> NTP did not respond. Trying clock correction using the HTTPS Date header..."

    local https_host="${HTTPS_TIME_HOST:-www.microsoft.com}"
    local t_before_ns t_after_ns header round_trip_ms

    t_before_ns=$(date +%s%N)
    header=$(curl -sI --max-time 5 "https://${https_host}" | grep -i '^date:' | sed 's/^[Dd]ate: //' | tr -d '\r')
    t_after_ns=$(date +%s%N)

    if [[ -z "$header" ]]; then
        echo "!!! Could not retrieve the Date header from https://${https_host}."
        return 1
    fi

    round_trip_ms=$(( (t_after_ns - t_before_ns) / 1000000 ))
    echo ">>> Date header from https://${https_host}: $header (round-trip ${round_trip_ms} ms)"

    if ! command -v powershell.exe &> /dev/null; then
        echo "!!! powershell.exe is missing; this script cannot set the Windows clock."
        echo "!!! Set manually to: $header"
        return 1
    fi

    MSYS2_ARG_CONV_EXCL='*' powershell.exe -NoProfile -Command "
        try {
            \$serverDate = [DateTime]::Parse('$header', [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::AssumeUniversal -bor [System.Globalization.DateTimeStyles]::AdjustToUniversal)
            \$corrected = \$serverDate.AddMilliseconds($round_trip_ms / 2).ToLocalTime()
            Set-Date -Date \$corrected -ErrorAction Stop
            Write-Output ('>>> Clock set to (local time): ' + \$corrected)
        } catch {
            Write-Output ('!!! Could not set the clock (run an elevated PowerShell): ' + \$_.Exception.Message)
            exit 1
        }
    "
}

echo ">>> Synchronizing clock with $NTP_SERVER..."

echo ">>> Local time before synchronization: $(date -u +'%Y-%m-%d %H:%M:%S.%3N UTC')"

if command -v chronyd &> /dev/null; then
    echo ">>> Using chronyd (one-shot sync)..."
    sudo chronyd -q "server $NTP_SERVER iburst" 2>&1 | grep -v "^$" || true

elif command -v ntpdate &> /dev/null; then
    echo ">>> Using ntpdate..."
    sudo ntpdate -u "$NTP_SERVER"

elif command -v sntp &> /dev/null; then
    echo ">>> Using sntp..."
    sudo sntp -sS "$NTP_SERVER"

elif command -v w32tm.exe &> /dev/null || command -v w32tm &> /dev/null; then
    echo ">>> Using w32tm (Windows)..."
    MSYS2_ARG_CONV_EXCL='*' w32tm.exe /config /manualpeerlist:"$NTP_SERVER" /syncfromflags:manual /update
    if ! MSYS2_ARG_CONV_EXCL='*' w32tm.exe /resync; then
        echo "!!! w32tm could not synchronize using NTP (UDP/123); it may be blocked"
        echo "!!! by VPN or endpoint security software (e.g. GlobalProtect), regardless of network."
        sync_via_https_fallback || exit 1
    fi

else
    echo "!!! None of chronyd/ntpdate/sntp/w32tm was found."
    echo "!!! Install one of them, e.g.: sudo apt-get install chrony"
    exit 1
fi

echo ">>> Local time after synchronization:  $(date -u +'%Y-%m-%d %H:%M:%S.%3N UTC')"
echo ">>> Clock synchronized. The k6 tests can now be started."
