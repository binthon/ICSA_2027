#!/bin/bash

set -euo pipefail

: "${APIM_URL:?Set APIM_URL}"
: "${SHORT_CODE:?Set SHORT_CODE (run register_device.js first)}"
: "${TOKEN_BROKER_URL:=http://127.0.0.1:8765/token}"
: "${ALLOW_WORKER_SWITCH:?Set ALLOW_WORKER_SWITCH=yes to permit exclusive switching of the submissions consumer}"

RATE="${RATE:-2}"
RUNS="${RUNS:-5}"
MIN_CREDITS="${MIN_CREDITS:-20}"
COOLDOWN_SEC="${COOLDOWN_SEC:-90}"
CONFIG_SWITCH_WAIT_SEC="${CONFIG_SWITCH_WAIT_SEC:-30}"
RG="${RG:-YOUR_AZURE_RESOURCE_GROUP}"
SB_NAMESPACE="${SB_NAMESPACE:-YOUR_SERVICEBUS_NAMESPACE}"
SB_QUEUE="${SB_QUEUE:-submissions}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
source "$SCRIPT_DIR/experiment_helpers.sh"

PROFILES=(constant daily spike spatial)
if [[ -n "${VARIANTS_LIST:-}" ]]; then
  read -ra VARIANTS <<< "$VARIANTS_LIST"
else
  VARIANTS=(hpa keda feedback)
fi

if [[ -n "${RUN_LIST:-}" ]]; then
  IFS=',' read -ra RUN_NUMS <<< "$RUN_LIST"
else
  RUN_NUMS=($(seq 1 "$RUNS"))
fi

shuffle_variants() {
  local i j tmp
  for ((i=${#VARIANTS[@]}-1; i>0; i--)); do
    j=$((RANDOM % (i+1)))
    tmp="${VARIANTS[i]}"; VARIANTS[i]="${VARIANTS[j]}"; VARIANTS[j]="$tmp"
  done
}
shuffle_variants
echo ">>> Variant order in this campaign: ${VARIANTS[*]}"

RESULTS_DIR="$TEST_DIR/results"
mkdir -p "$RESULTS_DIR"

switch_variant() {
  local variant="$1"
  echo ">>> Switching to variant $variant"
  bash "$SCRIPT_DIR/switch_worker_mode.sh" "$variant"
  sleep "$CONFIG_SWITCH_WAIT_SEC"
}

reset_replicas() {
  local variant="$1"
  case "$variant" in
    baseline|fixed)
      return 0
      ;;
    keda)
      echo ">>> KEDA reset: temporarily restrict to one replica"
      kubectl patch scaledobject "fa-worker-${variant}" -n fa-worker --type merge \
        -p '{"spec":{"minReplicaCount":1,"maxReplicaCount":1}}'
      sleep 15
      kubectl patch scaledobject "fa-worker-${variant}" -n fa-worker --type merge \
        -p '{"spec":{"minReplicaCount":1,"maxReplicaCount":4}}'
      ;;
    hpa|feedback)
      echo ">>> reset ${variant}: temporarily reduce HPA maxReplicas to one"
      kubectl patch hpa "fa-worker-${variant}" -n fa-worker --type=json -p='[{"op":"replace","path":"/spec/maxReplicas","value":1}]'
      kubectl scale deployment "fa-worker-${variant}" -n fa-worker --replicas=1
      sleep 15
      kubectl patch hpa "fa-worker-${variant}" -n fa-worker --type=json -p='[{"op":"replace","path":"/spec/maxReplicas","value":4}]'
      ;;
  esac
  kubectl rollout status deployment "fa-worker-${variant}" -n fa-worker --timeout=60s || true
}

for variant in "${VARIANTS[@]}"; do
  switch_variant "$variant"
  sync_test_clock

  for profile in "${PROFILES[@]}"; do
    for run in "${RUN_NUMS[@]}"; do
      echo ">>> profile=$profile variant=$variant run=$run/$RUNS"

      credits="$(az monitor metrics list --resource "/subscriptions/YOUR_AZURE_SUBSCRIPTION_ID/resourceGroups/YOUR_AZURE_RESOURCE_GROUP/providers/Microsoft.DBforPostgreSQL/flexibleServers/YOUR_POSTGRES_SERVER" --metric cpu_credits_remaining --interval PT5M --start-time "$(date -u -d '15 minutes ago' +%Y-%m-%dT%H:%M:%SZ)" --end-time "$(date -u +%Y-%m-%dT%H:%M:%SZ)" --query "value[0].timeseries[0].data[?average!=null] | [-1].average" -o tsv 2>/dev/null)"
      credits_int="${credits%%.*}"
      if [[ "$credits_int" =~ ^[0-9]+$ && "$credits_int" -lt "${MIN_CREDITS:-20}" ]]; then
        echo ">>> Database credits too low (${credits}); waiting 10 min..." >&2
        sleep 600
      fi

      wait_for_empty_queue

      actual_replicas=""
      for attempt in 1 2 3; do
        reset_replicas "$variant"
        sleep 60
        actual_replicas="$(kubectl get deployment "fa-worker-${variant}" -n fa-worker -o jsonpath='{.status.replicas}' 2>/dev/null)"
        echo ">>> reset attempt $attempt: replicas=$actual_replicas"
        if [[ "$actual_replicas" == "1" ]]; then break; fi
      done
      echo ">>> REPLIKI_PRZED_K6=${actual_replicas} variant=$variant profile=$profile run=$run"
      if [[ "$actual_replicas" != "1" ]]; then
        echo ">>> ERROR: reset failed after 3 attempts for $variant; aborting" >&2
        exit 1
      fi
      wait_for_empty_queue
      clock_msg="$(sudo chronyd -q "server time.windows.com iburst" 2>&1 | grep -i "wrong by" | tail -1)"
      echo ">>> Clock before run: ${clock_msg:-no data (ignored)}"
      RUN_ID="$(utc_run_id "e2_${profile}_${variant}_run${run}_resetok")"
      START=$(date -u +%Y-%m-%dT%H:%M:%SZ)
      set +e
      k6 run \
        --env PROFILE="$profile" \
        --env CONFIG="$variant" \
        --env RATE="$RATE" \
        --env RUN_ID="$RUN_ID" \
        --env VARIANT="$variant" \
        --env APIM_URL="$APIM_URL" \
        --env SHORT_CODE="$SHORT_CODE" \
        --env TOKEN_BROKER_URL="$TOKEN_BROKER_URL" \
        --out json="${RESULTS_DIR}/${profile}_${variant}_run${run}.json" \
        "$TEST_DIR/load_profiles.js"
      K6_STATUS=$?
      set -e
      END=$(date -u +%Y-%m-%dT%H:%M:%SZ)
      printf '{"run_id":"%s","variant":"%s","load_profile":"%s","rate":%s,"start":"%s","end":"%s","k6_exit_code":%s}\n' \
        "$RUN_ID" "$variant" "$profile" "$RATE" "$START" "$END" "$K6_STATUS" \
        > "${RESULTS_DIR}/${profile}_${variant}_run${run}_window.json"

      if (( K6_STATUS != 0 )); then
        echo "Run $RUN_ID failed k6 thresholds; the matrix was stopped." >&2
        exit "$K6_STATUS"
      fi

      echo ">>> cooldown ${COOLDOWN_SEC}s..."
      sleep "$COOLDOWN_SEC"
    done
  done
done

wait_for_empty_queue

echo ">>> E2 matrix complete. Results in $RESULTS_DIR"
