#!/usr/bin/env bash

wait_for_empty_queue() {
  local timeout="${QUEUE_DRAIN_TIMEOUT_SEC:-900}"
  local waited=0
  local active

  while (( waited <= timeout )); do
    active="$(az servicebus queue show \
      --resource-group "$RG" \
      --namespace-name "$SB_NAMESPACE" \
      --name "$SB_QUEUE" \
      --query countDetails.activeMessageCount \
      --output tsv | tr -d '\r')"

    if [[ "$active" == "0" ]]; then
      echo ">>> Queue $SB_NAMESPACE/$SB_QUEUE is empty"
      return 0
    fi

    echo ">>> Queue still has $active active messages; waiting 15 s"
    sleep 15
    waited=$((waited + 15))
  done

  echo "Queue did not drain within ${timeout} s." >&2
  return 1
}

utc_run_id() {
  local prefix="$1"
  printf '%s_%s' "$prefix" "$(date -u +%Y%m%dT%H%M%SZ)"
}

sync_test_clock() {
  if [[ "${SKIP_CLOCK_SYNC:-no}" == "yes" ]]; then
    echo ">>> Skipping clock synchronization (SKIP_CLOCK_SYNC=yes)"
    return 0
  fi
  bash "$SCRIPT_DIR/sync_clock.sh"
}
