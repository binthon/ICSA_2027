#!/usr/bin/env bash

set -euo pipefail

MODE="${1:-}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INFRA_DIR="$(cd "$SCRIPT_DIR/../.." && pwd)"
CHART="${CHART:-$INFRA_DIR/k8s/k8s_config/fa-worker/chart}"
FEEDBACK_VALUES="${FEEDBACK_VALUES:-$INFRA_DIR/k8s/k8s_config/k8s-fa-worker-feedback/worker-values.yaml}"
NAMESPACE="${WORKER_NAMESPACE:-fa-worker}"
RELEASE="${WORKER_RELEASE:-fa-worker}"
EXPECTED_CONTEXT="${EXPECTED_KUBE_CONTEXT:-YOUR_KUBECONFIG_CONTEXT}"
KEDA_IDENTITY_ID="${KEDA_IDENTITY_ID:-YOUR_KEDA_IDENTITY_ID}"
AZURE_RESOURCE_GROUP="${AZURE_RESOURCE_GROUP:-YOUR_AZURE_RESOURCE_GROUP}"
BASELINE_FUNCTION_APP="${BASELINE_FUNCTION_APP:-fa-worker}"

function_app_id() {
  az functionapp show \
    --resource-group "$AZURE_RESOURCE_GROUP" \
    --name "$BASELINE_FUNCTION_APP" \
    --query id -o tsv | tr -d '\r'
}

function_app_state() {
  local resource_id="$1"
  az rest \
    --method get \
    --url "https://management.azure.com${resource_id}?api-version=2024-04-01" \
    --query properties.state -o tsv | tr -d '\r'
}

if [[ ! "$MODE" =~ ^(baseline|fixed|hpa|keda|feedback)$ ]]; then
  echo "Usage: $0 baseline|fixed|hpa|keda|feedback" >&2
  exit 2
fi

if [[ "${ALLOW_WORKER_SWITCH:-}" != "yes" ]]; then
  echo "Set ALLOW_WORKER_SWITCH=yes to confirm changing the active consumer." >&2
  exit 2
fi

for command_name in az kubectl helm; do
  command -v "$command_name" >/dev/null || {
    echo "Required command is missing: $command_name" >&2
    exit 1
  }
done

current_context="$(kubectl config current-context)"
if [[ "$current_context" != "$EXPECTED_CONTEXT" ]]; then
  echo "Unexpected kubectl context: $current_context (expected $EXPECTED_CONTEXT)." >&2
  exit 1
fi

if [[ "$MODE" == "keda" ]]; then
  kubectl get crd scaledobjects.keda.sh >/dev/null
  kubectl -n kube-system get deployment keda-operator >/dev/null
fi

if [[ "$MODE" == "feedback" ]]; then
  MSYS_NO_PATHCONV=1 kubectl get --raw /apis/custom.metrics.k8s.io/v1beta1 >/dev/null
  [[ -f "$FEEDBACK_VALUES" ]] || {
    echo "Feedback values file is missing: $FEEDBACK_VALUES" >&2
    exit 1
  }
fi

echo ">>> Stopping autoscalers and all known pod worker variants"
kubectl -n "$NAMESPACE" delete scaledobject fa-worker fa-worker-keda --ignore-not-found
kubectl -n "$NAMESPACE" delete hpa \
  fa-worker fa-worker-hpa fa-worker-feedback keda-hpa-fa-worker-keda --ignore-not-found

for deployment_name in fa-worker fa-worker-fixed fa-worker-hpa fa-worker-keda fa-worker-feedback; do
  if kubectl -n "$NAMESPACE" get deployment "$deployment_name" >/dev/null 2>&1; then
    kubectl -n "$NAMESPACE" scale deployment "$deployment_name" --replicas=0
  fi
done

if kubectl -n "$NAMESPACE" get pod \
  -l "app.kubernetes.io/instance=$RELEASE" -o name | grep -q .; then
  kubectl -n "$NAMESPACE" wait --for=delete pod \
    -l "app.kubernetes.io/instance=$RELEASE" --timeout=180s || {
      echo "The previous worker pod did not terminate within the required time." >&2
      exit 1
    }
fi

if [[ "$MODE" == "baseline" ]]; then
  echo ">>> Starting baseline Azure Function: $BASELINE_FUNCTION_APP"
  baseline_resource_id="$(function_app_id)"
  az rest --method post \
    --url "https://management.azure.com${baseline_resource_id}/start?api-version=2024-04-01" \
    --output none

  for _ in $(seq 1 30); do
    function_state="$(function_app_state "$baseline_resource_id")"
    [[ "$function_state" == "Running" ]] && break
    sleep 5
  done

  if [[ "${function_state:-}" != "Running" ]]; then
    echo "Azure Function $BASELINE_FUNCTION_APP did not reach Running state." >&2
    exit 1
  fi

  echo ">>> Active variant: baseline (Function App/$BASELINE_FUNCTION_APP)"
  az functionapp show \
    --resource-group "$AZURE_RESOURCE_GROUP" \
    --name "$BASELINE_FUNCTION_APP" \
    --query '{name:name,state:state}' -o table
  exit 0
fi

echo ">>> Stopping baseline Azure Function before starting the pod"
baseline_resource_id="$(function_app_id)"
az rest --method post \
  --url "https://management.azure.com${baseline_resource_id}/stop?api-version=2024-04-01" \
  --output none

for _ in $(seq 1 30); do
  function_state="$(function_app_state "$baseline_resource_id")"
  [[ "$function_state" == "Stopped" ]] && break
  sleep 5
done

if [[ "${function_state:-}" != "Stopped" ]]; then
  echo "Azure Function $BASELINE_FUNCTION_APP did not reach Stopped state." >&2
  exit 1
fi

common_args=(
  upgrade --install "$RELEASE" "$CHART"
  --namespace "$NAMESPACE" --create-namespace --reset-values
  --set replicaCount=1
  --set worker.enabled=true
  --set autoscaling.hpa.enabled=false
  --set autoscaling.keda.enabled=false
  --set autoscaling.feedback.enabled=false
  --wait --timeout 5m
)

case "$MODE" in
  fixed)
    helm "${common_args[@]}" --set-string fullnameOverride=fa-worker-fixed
    target=fa-worker-fixed
    ;;
  hpa)
    helm "${common_args[@]}" \
      --set-string fullnameOverride=fa-worker-hpa \
      --set autoscaling.hpa.enabled=true \
      --set autoscaling.hpa.minReplicas=1 \
      --set autoscaling.hpa.maxReplicas=4 \
      --set autoscaling.hpa.targetCPUUtilizationPercentage=3
    target=fa-worker-hpa
    ;;
  keda)
    helm "${common_args[@]}" \
      --set-string fullnameOverride=fa-worker-keda \
      --set autoscaling.keda.enabled=true \
      --set autoscaling.keda.minReplicas=1 \
      --set autoscaling.keda.maxReplicas=4 \
      --set autoscaling.keda.pollingInterval=15 \
      --set autoscaling.keda.cooldownPeriod=300 \
      --set autoscaling.keda.queueName=submissions \
      --set autoscaling.keda.messageCount=3 \
      --set autoscaling.keda.activationMessageCount=1 \
      --set-string autoscaling.keda.identityId="$KEDA_IDENTITY_ID"
    target=fa-worker-keda
    ;;
  feedback)
    helm "${common_args[@]}" \
      -f "$FEEDBACK_VALUES" \
      --set autoscaling.feedback.enabled=true
    target=fa-worker-feedback
    ;;
esac

kubectl -n "$NAMESPACE" scale "deployment/$target" --replicas=1
kubectl -n "$NAMESPACE" rollout status "deployment/$target" --timeout=180s
echo ">>> Active variant: $MODE (deployment/$target)"
kubectl -n "$NAMESPACE" get deployment,pods,hpa,scaledobject
