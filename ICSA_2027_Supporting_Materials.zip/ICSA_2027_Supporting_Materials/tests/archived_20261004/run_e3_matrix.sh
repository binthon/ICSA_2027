#!/bin/bash

set -euo pipefail

: "${APIM_URL:?Set APIM_URL}"
: "${SHORT_CODE:?Set SHORT_CODE}"
: "${TOKEN_BROKER_URL:=http://127.0.0.1:8765/token}"
: "${RG:?Set RG (Azure resource group)}"
: "${PG_SERVER:?Set PG_SERVER (PostgreSQL Flexible Server name)}"
: "${ALLOW_WORKER_SWITCH:?Set ALLOW_WORKER_SWITCH=yes after stopping Azure Function fa-worker}"

RUNS="${RUNS:-3}"
COOLDOWN_SEC="${COOLDOWN_SEC:-90}"
SB_NAMESPACE="${SB_NAMESPACE:-YOUR_SERVICEBUS_NAMESPACE}"
SB_QUEUE="${SB_QUEUE:-submissions}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
RESULTS_DIR="$TEST_DIR/results"
mkdir -p "$RESULTS_DIR"
source "$SCRIPT_DIR/experiment_helpers.sh"

ORIGINAL_SKU="$(az postgres flexible-server show --resource-group "$RG" --name "$PG_SERVER" --query sku.name -o tsv)"
ORIGINAL_TIER="$(az postgres flexible-server show --resource-group "$RG" --name "$PG_SERVER" --query sku.tier -o tsv)"

restore_db_tier() {
  echo ">>> Restoring the original database tier: $ORIGINAL_SKU ($ORIGINAL_TIER)"
  az postgres flexible-server update --resource-group "$RG" --name "$PG_SERVER" \
    --sku-name "$ORIGINAL_SKU" --tier "$ORIGINAL_TIER" >/dev/null
}
trap restore_db_tier EXIT

set_db_tier() {
  local sku="$1" tier="$2"
  local waited=0
  echo ">>> Setting database to $sku ($tier)"
  az postgres flexible-server update --resource-group "$RG" --name "$PG_SERVER" \
    --sku-name "$sku" --tier "$tier"

  echo ">>> Waiting for server restart..."
  while true; do
    state=$(az postgres flexible-server show --resource-group "$RG" --name "$PG_SERVER" --query "state" -o tsv)
    [ "$state" = "Ready" ] && break
    if (( waited >= 1800 )); then
      echo "PostgreSQL did not reach Ready state within 30 min." >&2
      return 1
    fi
    sleep 15
    waited=$((waited + 15))
  done
}

lock_pods() {
  echo ">>> Fixing pod count (replicas=5, HPA/KEDA disabled)"
  bash "$SCRIPT_DIR/switch_worker_mode.sh" fixed
  kubectl -n fa-worker scale deployment fa-worker-fixed --replicas=5
  kubectl -n fa-worker rollout status deployment/fa-worker-fixed --timeout=180s
  sleep 30
}

unlock_pods() {
  echo ">>> Enabling pod autoscaling (HPA/CPU as the scaling mechanism)"
  bash "$SCRIPT_DIR/switch_worker_mode.sh" hpa
  sleep 30
}

run_sweep_set() {
  local variant="$1"
  echo ">>> Clock synchronization before block: $variant"
  sync_test_clock

  for run in $(seq 1 "$RUNS"); do
    echo ">>> variant=$variant run=$run/$RUNS"
    wait_for_empty_queue
    RUN_ID="$(utc_run_id "e3_${variant}_run${run}")"
    START=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    set +e
    k6 run \
      --env APIM_URL="$APIM_URL" \
      --env SHORT_CODE="$SHORT_CODE" \
      --env TOKEN_BROKER_URL="$TOKEN_BROKER_URL" \
      --env RUN_ID="$RUN_ID" \
      --env VARIANT="$variant" \
      --out json="${RESULTS_DIR}/e3_${variant}_run${run}.json" \
      "$TEST_DIR/saturation_sweep.js"
    K6_STATUS=$?
    set -e
    END=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    printf '{"run_id":"%s","variant":"%s","load_profile":"saturation_sweep","start":"%s","end":"%s","k6_exit_code":%s}\n' \
      "$RUN_ID" "$variant" "$START" "$END" "$K6_STATUS" \
      > "${RESULTS_DIR}/e3_${variant}_run${run}_window.json"

    if (( K6_STATUS != 0 )); then
      echo "Run $RUN_ID failed k6 thresholds; the matrix was stopped." >&2
      exit "$K6_STATUS"
    fi
    sleep "$COOLDOWN_SEC"
  done
}

set_db_tier "Standard_B2s" "Burstable"

lock_pods
run_sweep_set "burstable_locked"

unlock_pods
run_sweep_set "burstable_unlocked"

set_db_tier "Standard_D2s_v3" "GeneralPurpose"

lock_pods
run_sweep_set "gp_locked"

unlock_pods
run_sweep_set "gp_unlocked"

wait_for_empty_queue

echo ">>> E3 matrix complete. Results in $RESULTS_DIR"
