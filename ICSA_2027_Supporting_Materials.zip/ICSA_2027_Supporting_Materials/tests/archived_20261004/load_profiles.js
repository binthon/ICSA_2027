import http from 'k6/http';
import { check } from 'k6';
import {
  BASE_URL, PROFILE, CONFIG, RUN_ID, SUBSCRIPTION_KEY, TOKEN_BROKER_URL, VARIANT,
} from './lib/config.js';
import { getToken } from './lib/auth.js';
import { buildTelemetryPayload } from './lib/payload.js';

const RATE = Number(__ENV.RATE || 5);
const SHORT_PROFILE_DURATION = __ENV.DURATION || '15m';

if (!Number.isFinite(RATE) || RATE <= 0) {
  throw new Error(`RATE must be greater than zero; received: ${__ENV.RATE}`);
}

if (!TOKEN_BROKER_URL) {
  throw new Error('The load test requires --env TOKEN_BROKER_URL=http://127.0.0.1:8765/token');
}

function buildScenario(profile) {
  switch (profile) {
    case 'constant':
      return {
        executor: 'constant-arrival-rate',
        rate: RATE, timeUnit: '1s', duration: SHORT_PROFILE_DURATION,
        preAllocatedVUs: 200, maxVUs: 500,
      };

    case 'daily':
      return {
        executor: 'ramping-arrival-rate',
        startRate: Math.round(RATE * 0.2), timeUnit: '1s',
        preAllocatedVUs: 200, maxVUs: 500,
        stages: [
          { target: Math.round(RATE * 0.2), duration: '5m' },
          { target: Math.round(RATE * 3), duration: '10m' },
          { target: Math.round(RATE * 0.5), duration: '10m' },
          { target: Math.round(RATE * 5), duration: '10m' },
          { target: Math.round(RATE * 0.2), duration: '5m' },
        ],
      };

    case 'spike':
      return {
        executor: 'ramping-arrival-rate',
        startRate: RATE, timeUnit: '1s',
        preAllocatedVUs: 200, maxVUs: 800,
        stages: [
          { target: RATE, duration: '5m' },
          { target: RATE * 10, duration: '30s' },
          { target: RATE * 10, duration: '5m' },
          { target: RATE, duration: '2m' },
        ],
      };

    case 'spatial':
      return {
        executor: 'constant-arrival-rate',
        rate: RATE, timeUnit: '1s', duration: SHORT_PROFILE_DURATION,
        preAllocatedVUs: 200, maxVUs: 500,
      };

    default:
      throw new Error(`Unknown PROFILE: "${profile}". Use: constant | daily | spike | spatial`);
  }
}

export const options = {
  scenarios: { [PROFILE]: buildScenario(PROFILE) },
  thresholds: {
    http_req_failed: ['rate<0.03'],
    checks: ['rate>0.97'],
    dropped_iterations: ['count==0'],
  },
};

export default function () {
  
  const token = getToken();
  const isSpatial = PROFILE === 'spatial';
  const payload = buildTelemetryPayload(isSpatial);
  const headers = { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` };
  if (SUBSCRIPTION_KEY) headers['Ocp-Apim-Subscription-Key'] = SUBSCRIPTION_KEY;

  const res = http.post(`${BASE_URL}/submit`, JSON.stringify(payload), {
    headers,
    tags: {
      name: 'submit', run_id: RUN_ID,
      profile: PROFILE, config: CONFIG, variant: VARIANT,
    },
  });

  check(res, {
    'status 202': (r) => r.status === 202,
    'event_id zachowany': (r) => {
      try { return r.json('event_id') === payload.event_id; } catch (_) { return false; }
    },
  });
}
