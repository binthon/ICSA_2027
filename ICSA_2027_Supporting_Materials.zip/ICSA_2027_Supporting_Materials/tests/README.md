# Reference test scripts

- archived_20261004/: seven sanitized campaign scripts: E2/E3 runners, workload
  generation, collection, worker switching, and clock synchronization helpers.
  The stand-alone backup and data-deletion utilities were omitted.
  The obsolete E3 sweep runner (B2s, five fixed pods) was also omitted;
  the retained E3 runners implement fixed-N queue-drain experiments.
- current_e3_reference/: four sanitized E3 runner/export references. The runner
  from before the General Purpose campaign is named run_e3_before_gp.sh.
- current_k6_library_reference/: current authentication, configuration, and
  payload helper snapshots. The historical archive lacks its imported lib
  directory; these current files are not verified historical dependencies.

Comments were removed and user-facing messages translated into English. Parameters,
commands, historical paths, and technical identifiers were preserved. These files
are edited reference copies, not byte-identical historical snapshots.

Cloud scripts require separately configured Azure/Kubernetes resources, k6,
environment settings, authentication, and missing payload/helper files. Some
scripts switch active consumers, change replica counts/database tiers, or adjust
the local clock. No cloud script was executed during packaging.

Numerical reproduction only requires the following command at the archive root:

    python -I artifact/analyze.py

It reads packaged CSV files without Azure, SQL, or shell-script execution.
Environment addresses and identifiers remain descriptive placeholders; credentials
and original coordinate/device payload pools are not included.
