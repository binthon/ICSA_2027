#!/bin/bash
CSV="${1:?provide a file, e.g. results_e3/e3_20261005T185703.csv}"
OUTD="${CSV%.csv}_metryki"; mkdir -p "$OUTD"
DB=$(az postgres flexible-server show -g YOUR_AZURE_RESOURCE_GROUP -n YOUR_POSTGRES_SERVER --query id -o tsv | tr -d '\r')
SB=$(az servicebus namespace show -g YOUR_AZURE_RESOURCE_GROUP -n YOUR_SERVICEBUS_NAMESPACE --query id -o tsv | tr -d '\r')
kubectl port-forward -n monitoring svc/monitoring-kube-prometheus-prometheus 9090:9090 >/dev/null 2>&1 & PF=$!
until curl -sf http://localhost:9090/-/ready >/dev/null; do sleep 2; done
q() { curl -s -G http://localhost:9090/api/v1/query_range --data-urlencode "query=$1" --data-urlencode "start=$2" --data-urlencode "end=$3" --data-urlencode "step=5"; }
tail -n +2 "$CSV" | while IFS=, read -r prof N start end rest; do
  tag="${prof}_N${N}_$(echo "$start" | tr -d ':-')"
  s=$(date -d "$start" +%s); e=$(( $(date -d "$end" +%s) + 60 ))
  endiso=$(date -u -d "@$e" +%Y-%m-%dT%H:%M:%SZ)
  echo ">>> $tag"
  q 'sum(rate(worker_messages_inserted_total[30s]))' $s $e > "$OUTD/$tag.throughput.json" </dev/null
  q 'sum(kube_deployment_status_replicas_ready{deployment="fa-worker-fixed"})' $s $e > "$OUTD/$tag.replicas.json" </dev/null
  for c in duplicate failed abandoned invalid; do
    q "sum(worker_messages_${c}_total)" $s $e > "$OUTD/$tag.$c.json" </dev/null
  done
  for m in cpu_percent active_connections cpu_credits_remaining; do
    az monitor metrics list --resource "$DB" --metric $m --interval PT1M --start-time "$start" --end-time "$endiso" \
      --query "value[0].timeseries[0].data[].[timeStamp,average,maximum]" -o tsv </dev/null > "$OUTD/$tag.db_$m.tsv"
  done
  az monitor metrics list --resource "$SB" --metric ActiveMessages --interval PT1M --aggregation Maximum --start-time "$start" --end-time "$endiso" \
    --query "value[0].timeseries[0].data[].[timeStamp,maximum]" -o tsv </dev/null > "$OUTD/$tag.sb_queue.tsv"
done
kill $PF
ls "$OUTD" | wc -l
