#!/bin/bash
OUTD="archiwum_E3_surowe"; mkdir -p "$OUTD"
WS=$(az monitor log-analytics workspace show -g YOUR_AZURE_RESOURCE_GROUP -n YOUR_LOG_ANALYTICS_WORKSPACE --query customerId -o tsv | tr -d '\r')
for f in results_e3/e3_2*.csv results_e3_gp/e3_2*.csv; do
  [ $(wc -l < "$f") -gt 1 ] || continue
  tier=burstable; case "$f" in *_gp/*) tier=gp;; esac
  tail -n +2 "$f" | while IFS=, read -r prof N s e rest; do
    tag="${tier}_${prof}_N${N}_$(echo "$s" | tr -d ':-')"
    echo ">>> $tag"
    printf "time_generated\tpod\teid\tcon_ms\tins_ms\ttot_ms\n" > "$OUTD/$tag.tsv"
    az monitor log-analytics query --workspace "$WS" -o json </dev/null --analytics-query "ContainerLogV2 | where TimeGenerated between (datetime($s) .. datetime($e) + 1m) | where PodName startswith 'fa-worker-fixed' and LogMessage contains 'LAT event_id' | parse LogMessage with * 'event_id=' eid:string ' ' * | parse LogMessage with * 'worker_db_connect_duration=' con:real ' ' * | parse LogMessage with * 'worker_db_insert_duration=' ins:real ' ' * | parse LogMessage with * 'worker_total_duration=' tot:real ' ' * | project TimeGenerated, PodName, eid, con, ins, tot | order by TimeGenerated asc" \
      | jq -r '.[] | [.TimeGenerated,.PodName,.eid,.con,.ins,.tot] | @tsv' >> "$OUTD/$tag.tsv"
    echo "    rows: $(($(wc -l < "$OUTD/$tag.tsv")-1))"
  done
done
