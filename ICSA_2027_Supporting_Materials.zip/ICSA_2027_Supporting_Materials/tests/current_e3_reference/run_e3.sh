#!/bin/bash
set -eo pipefail
TIER=$(az postgres flexible-server show -g YOUR_AZURE_RESOURCE_GROUP -n YOUR_POSTGRES_SERVER --query sku.tier -o tsv | tr -d '\r')
echo ">>> database tier: $TIER"
if [ -n "$E3_REQUIRE_TIER" ] && [ "$TIER" != "$E3_REQUIRE_TIER" ]; then echo "Required tier: $E3_REQUIRE_TIER; actual tier: $TIER. Stopping"; exit 1; fi
trap 'kubectl scale deployment fa-worker-fixed -n fa-worker --replicas=1 >/dev/null 2>&1' EXIT
source ~/env_icsa.sh
export ALLOW_WORKER_SWITCH=yes
curl -sf "$TOKEN_BROKER_URL" >/dev/null || { echo "Token broker is unavailable (run: python3 ./scripts/token_broker.py)"; exit 1; }
LEVELS="${LEVELS:-1 2 4 8 16}"
FILL_RATE="${FILL_RATE:-10}"; FILL_DUR="${FILL_DUR:-5m}"
MIN_CREDITS_E3="${MIN_CREDITS_E3:-60}"
mkdir -p ${E3_DIR:-results_e3}
OUT=${E3_DIR:-results_e3}/e3_$(date -u +%Y%m%dT%H%M%S).csv
echo "profile,N,start_utc,end_utc,backlog,drain_s,msg_per_s,credits_before,credits_after,pods_not_running" > "$OUT"

credits() { az monitor metrics list --resource "/subscriptions/YOUR_AZURE_SUBSCRIPTION_ID/resourceGroups/YOUR_AZURE_RESOURCE_GROUP/providers/Microsoft.DBforPostgreSQL/flexibleServers/YOUR_POSTGRES_SERVER" --metric cpu_credits_remaining --interval PT5M --start-time "$(date -u -d '15 minutes ago' +%Y-%m-%dT%H:%M:%SZ)" --end-time "$(date -u +%Y-%m-%dT%H:%M:%SZ)" --query "value[0].timeseries[0].data[?average!=null] | [-1].average" -o tsv | tr -d '\r'; }
qlen() { az servicebus queue show -g YOUR_AZURE_RESOURCE_GROUP --namespace-name YOUR_SERVICEBUS_NAMESPACE --name submissions --query "countDetails.activeMessageCount" -o tsv | tr -d '\r'; }

bash ./scripts/switch_worker_mode.sh fixed
for i in $(seq 1 36); do [ "$(qlen)" = "0" ] && break; sleep 5; done
[ "$(qlen)" = "0" ] || { echo "Queue is not empty after 3 min; stopping"; exit 1; }
for N in $LEVELS; do
  c0=$(credits | grep -E '^[0-9.]+' || true); c0=${c0:-999}; echo ">>> N=$N credits=$c0"
  if (( ${c0%%.*} < MIN_CREDITS_E3 )); then echo "Insufficient credits; stopping"; exit 1; fi

  kubectl scale deployment fa-worker-fixed -n fa-worker --replicas=0
  sleep 20
  k6 run --env PROFILE=${FILL_PROFILE:-constant} --env CONFIG=fixed --env RATE=$FILL_RATE --env DURATION=$FILL_DUR \
    --env RUN_ID=e3_fill_N$N --env VARIANT=fixed --env APIM_URL="$APIM_URL" \
    --env SHORT_CODE="$SHORT_CODE" --env TOKEN_BROKER_URL="$TOKEN_BROKER_URL" load_profiles.js >/dev/null
  sleep 10
  backlog=$(qlen); echo ">>> backlog=$backlog"
  if (( backlog < 100 )); then echo "Queue did not fill (backlog=$backlog); stopping"; exit 1; fi

  START=$(date -u +%Y-%m-%dT%H:%M:%SZ); t0=$(date +%s)
  kubectl scale deployment fa-worker-fixed -n fa-worker --replicas=$N
  while [ "$(qlen)" != "0" ]; do
    if (( $(date +%s) - t0 > 1800 )); then echo "timeout"; break; fi
    sleep 5
  done
  t1=$(date +%s); END=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  d=$((t1-t0)); rate=$(python3 -c "print(round($backlog/max($d,1),2))")
  c1=$(credits | grep -E '^[0-9.]+' || true); c1=${c1:-NA}
  notrun=$(kubectl get pods -n fa-worker --no-headers | grep -vc Running || true)
  echo "${FILL_PROFILE:-constant},$N,$START,$END,$backlog,$d,$rate,$c0,$c1,$notrun" | tee -a "$OUT"
  sleep 120
done
kubectl scale deployment fa-worker-fixed -n fa-worker --replicas=1
echo ">>> E3 complete: $OUT"
