# Reproduced numerical results

E2: 82 archived exports, 78 qualified runs, 4 incomplete exports excluded from aggregation.
All 445,427 exported rows are retained in reduced form; qualified runs contain 426,274 rows.
E3: all 28 rounds and 84,016 exported events are retained. No new cloud tests were run.

## E3 throughput by group

| Tier | Profile | Workers N | Rounds | Mean [messages/s] | Sample SD | Min | Max |
|---|---|---:|---:|---:|---:|---:|---:|
| burstable | constant | 1 | 3 | 6.848245 | 0.190122 | 6.643817 | 7.019764 |
| burstable | constant | 2 | 3 | 9.712925 | 0.114466 | 9.611217 | 9.836882 |
| burstable | constant | 4 | 2 | 9.552661 | 0.207813 | 9.405715 | 9.699607 |
| burstable | constant | 8 | 3 | 9.678203 | 0.137123 | 9.588033 | 9.836004 |
| burstable | constant | 16 | 3 | 9.326773 | 0.154708 | 9.158073 | 9.462013 |
| burstable | spatial | 4 | 2 | 9.749463 | 0.045805 | 9.717074 | 9.781853 |
| gp | constant | 1 | 2 | 8.121126 | 0.006632 | 8.116436 | 8.125816 |
| gp | constant | 2 | 2 | 15.940970 | 0.417347 | 15.645861 | 16.236079 |
| gp | constant | 3 | 2 | 18.839820 | 0.130536 | 18.747517 | 18.932123 |
| gp | constant | 4 | 2 | 18.655945 | 0.936194 | 17.993956 | 19.317935 |
| gp | constant | 8 | 2 | 18.590223 | 0.216070 | 18.437438 | 18.743007 |
| gp | constant | 16 | 2 | 18.183737 | 0.569471 | 17.781060 | 18.586413 |

## E2: all qualified series

| Series | Policy | Runs | Median per-run p95 [s] | Min p95 | Max p95 | Median mean observed pods |
|---|---|---:|---:|---:|---:|---:|
| constant_earlier | feedback | 5 | 0.197205 | 0.196600 | 0.204900 | 3.500000 |
| constant_earlier | hpa | 5 | 0.202400 | 0.197100 | 0.205200 | 1.933333 |
| constant_earlier | keda | 5 | 0.196900 | 0.187900 | 0.207150 | 1.000000 |
| daily_control | feedback | 2 | 0.661575 | 0.522400 | 0.800750 | 3.575000 |
| daily_control | hpa | 2 | 1.025095 | 0.894510 | 1.155680 | 3.000000 |
| daily_earlier | feedback | 5 | 0.613160 | 0.473500 | 1.182465 | 3.625000 |
| daily_earlier | hpa | 5 | 0.510410 | 0.472600 | 0.615450 | 2.975000 |
| daily_earlier | keda | 5 | 0.769290 | 0.446010 | 0.890230 | 1.675000 |
| spatial_corrective | feedback | 5 | 0.202200 | 0.199700 | 0.213400 | 3.466667 |
| spatial_corrective | keda | 5 | 0.194000 | 0.185805 | 0.199100 | 1.000000 |
| spatial_earlier | hpa | 5 | 0.199800 | 0.191300 | 0.215400 | 1.933333 |
| spatial_earlier | keda | 5 | 0.185495 | 0.182000 | 0.209510 | 1.000000 |
| spike_earlier | feedback | 2 | 328.763040 | 328.082380 | 329.443700 | 3.923077 |
| spike_earlier | hpa | 5 | 332.094640 | 329.125800 | 338.108640 | 4.000000 |
| spike_earlier | keda | 4 | 366.086210 | 339.656020 | 387.473200 | 11.384615 |
| spike_observational | feedback | 5 | 340.343920 | 335.400440 | 344.895880 | 4.000000 |
| spike_observational | hpa | 4 | 345.969530 | 343.635160 | 354.742860 | 3.923077 |
| spike_observational | keda | 4 | 342.671140 | 339.689980 | 346.562840 | 3.919872 |

Series with different configurations remain separate. Observed pod-name counts are not Ready replica-minutes or monetary cost.
E3 concerns the measured worker/database path, not PostgreSQL's maximum capacity. See artifact/README.md for definitions.

Canonical numerical-result SHA-256: da2fe15afaa4ed05fdb17751fb4fe7a7ebe7024c8b2dac432f50eef97de0482e
